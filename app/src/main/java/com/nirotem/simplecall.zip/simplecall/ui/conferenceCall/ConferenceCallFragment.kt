package com.nirotem.simplecall.ui.conferenceCall

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.widget.AppCompatImageButton
import androidx.appcompat.widget.AppCompatTextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.nirotem.simplecall.OngoingCall
import com.nirotem.simplecall.R
import com.nirotem.simplecall.databinding.FragmentConferenceCallBinding

class ConferenceCallFragment : Fragment() {
    private lateinit var textViewPhoneNumber: TextView
    private var isSpeakerOn: Boolean = false
    private var _binding: FragmentConferenceCallBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Get the phone number from the arguments (passed from the activity)
        val phoneNumber = arguments?.getString("CALLER_NUMBER") ?: "Unknown Caller"
        val phoneNumber2 = arguments?.getString("CALLER_NUMBER2") ?: "Unknown Caller"

        // Use ViewModelFactory to create the ViewModel
        val incomingCallViewModel = ViewModelProvider(this,
            ConferenceCallViewModel.ConferenceCallViewModelFactory(phoneNumber)
        ).get(ConferenceCallViewModel::class.java)

        _binding = FragmentConferenceCallBinding.inflate(inflater, container, false)
        val root: View = binding.root

        textViewPhoneNumber = binding.textConferenceCallContact
        val contactLabel = binding.root.findViewById<AppCompatTextView>(R.id.text_conference_call_contact)
        contactLabel.text = phoneNumber
        val contactLabel2 = binding.root.findViewById<AppCompatTextView>(R.id.text_conference_call_contact2)
        contactLabel2.text = phoneNumber2
       // textViewContactName = binding.textIncomingCallLabel

/*        val textView: TextView = binding.textIncomingCallContact
        incomingCallViewModel.text.observe(viewLifecycleOwner) {
            textView.text = phoneNumber
        }*/
        val declineButton = binding.root.findViewById<AppCompatImageButton>(R.id.declineButton)

        declineButton.setOnClickListener { // decline call and hide screen
            Log.d("SimplyCall - ActiveCallFragment", "declineButton clicked - Fragment")
            OngoingCall.hangup()
            exitTransition = android.transition.Fade() // Add fade effect
            parentFragmentManager.beginTransaction()
                .remove(this)
                .commit()
        }
        val speakerButton = binding.root.findViewById<AppCompatImageButton>(R.id.speakerButton)
        if (isSpeakerphoneOn(this.requireContext())) {
            speakerButton.setImageResource(R.drawable.speaker_on)
        }

        speakerButton.setOnClickListener { // decline call and hide screen
            if (this.context !== null) {
             //   Log.d("SimplyCall - ActiveCallFragment", "set Speaker before: (isSpeakerOn = $isSpeakerOn), (isSpeakerphoneOn(this.requireContext()) = ${isSpeakerphoneOn(this.requireContext())}")
                if (isSpeakerOn) {
                    setSpeakerphone(this.requireContext(), false)
                    speakerButton.setImageResource(R.drawable.speaker)
                }
                else {
                    setSpeakerphone(this.requireContext(), true)
                    speakerButton.setImageResource(R.drawable.speaker_on)
                }
                    // Log.d("SimplyCall - ActiveCallFragment", "set Speaker after: (isSpeakerOn = $isSpeakerOn), (isSpeakerphoneOn(this.requireContext()) = ${isSpeakerphoneOn(this.requireContext())}")
            }
        }
        return root
    }

    override fun onDetach() {
        super.onDetach()
        requireActivity().finish()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    fun updateText(newPhoneOrContact: String) {
       // val contactLabel = binding.root.findViewById<AppCompatTextView>(R.id.text_active_call_contact)
       // contactLabel.text = newPhoneOrContact
        //textViewPhoneNumber = newPhoneOrContact
        // not implemented yet
    }

    private fun setSpeakerphone(context: Context, enable: Boolean) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.requestAudioFocus(
            null, // ניתן להוסיף Listener לשינויים אם צריך
            AudioManager.STREAM_VOICE_CALL,
            AudioManager.AUDIOFOCUS_GAIN
        )
        audioManager.setMode(AudioManager.MODE_IN_CALL)
        //audioManager.isSpeakerphoneOn = true

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val speakerphone = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            if (enable && speakerphone != null) {
                audioManager.setCommunicationDevice(speakerphone)
            } else {
                audioManager.clearCommunicationDevice()
            }
        } else { // Older versions
            audioManager.isSpeakerphoneOn = enable
        }
        isSpeakerOn = enable
    }

    fun isSpeakerphoneOn(context: Context): Boolean {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager


        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // בודקים אם הספיקר מוגדר כמכשיר התקשורת הפעיל
            val currentDevice = audioManager.communicationDevice
            currentDevice?.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
        } else {
            // בגרסאות ישנות יותר, משתמשים במאפיין הישן
            audioManager.isSpeakerphoneOn
        }
    }

    private fun toggleSpeakerphone() {
        isSpeakerOn = !isSpeakerOn
        val audioManager = requireContext().getSystemService(Context.AUDIO_SERVICE) as AudioManager

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            audioManager.mode = AudioManager.MODE_IN_CALL
            audioManager.isSpeakerphoneOn = isSpeakerOn // Fallback for older versions
            Log.d(
                "SimplyCall - EventScreenActivity",
                "Turn audioManager.isSpeakerphoneOn = $audioManager.isSpeakerphoneOn (isSpeakerOn = $isSpeakerOn)"
            )
        } else {
            modernToggleSpeakerphone(isSpeakerOn)
        }
    }

    @RequiresApi(Build.VERSION_CODES.S)
    fun modernToggleSpeakerphone(enable: Boolean) {
        val audioManager = requireContext().getSystemService(Context.AUDIO_SERVICE) as AudioManager

        if (enable) {
            Log.d(
                "SimplyCall - EventScreenActivity",
                "Turn audioManager true, $audioManager.isSpeakerphoneOn = $audioManager.isSpeakerphoneOn"
            )

            val devices = audioManager.availableCommunicationDevices
            val speakerDevice = devices.find { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            if (speakerDevice != null) {
                audioManager.setCommunicationDevice(speakerDevice)
            } else {
                Log.e("SpeakerControl", "Speakerphone device not found!")
            }
            Log.d(
                "SimplyCall - EventScreenActivity",
                "Turn audioManager true (after), $audioManager.isSpeakerphoneOn = $audioManager.isSpeakerphoneOn"
            )
        } else {
            Log.d(
                "SimplyCall - EventScreenActivity",
                "Turn audioManager false, $audioManager.isSpeakerphoneOn = $audioManager.isSpeakerphoneOn"
            )
            audioManager.clearCommunicationDevice()
            Log.d(
                "SimplyCall - EventScreenActivity",
                "Turn audioManager false (after), $audioManager.isSpeakerphoneOn = $audioManager.isSpeakerphoneOn"
            )
        }

    }
}
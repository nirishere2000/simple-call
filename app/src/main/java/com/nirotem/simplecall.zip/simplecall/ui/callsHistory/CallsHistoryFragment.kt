package com.nirotem.simplecall.ui.callsHistory

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.text.format.DateUtils
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import androidx.core.database.getIntOrNull
import androidx.core.database.getLongOrNull
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.nirotem.simplecall.adapters.CallHistoryAdapter
import com.nirotem.simplecall.OutgoingCall
import com.nirotem.simplecall.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.*

class CallsHistoryFragment : Fragment(R.layout.fragment_calls_history) {

    private lateinit var recyclerView: RecyclerView
    private lateinit var callHistoryAdapter: CallHistoryAdapter
    private lateinit var progressBar: ProgressBar

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        try {
            OutgoingCall.isCalling = false
            progressBar = view.findViewById(R.id.progressBar)
            recyclerView = view.findViewById(R.id.recyclerView)

            recyclerView.layoutManager = LinearLayoutManager(requireContext())

            // Load data asynchronously
            lifecycleScope.launch {
                showLoading() // Show ProgressBar
                val callHistoryList = loadCallHistoryAsync()
                setupRecyclerView(callHistoryList)
                hideLoading() // Hide ProgressBar
            }
        }
        catch (error: Error) {
            Log.e("SimplyCall - CallsHistoryFragment", "CallsHistoryFragment onViewCreated Error ($error)")
        }


        // Set adapter for RecyclerView
       // callHistoryAdapter = CallHistoryAdapter(loadCallHistory())
       // recyclerView.adapter = callHistoryAdapter


    }

    private fun setupRecyclerView(callHistoryList: List<PhoneCall2>) {
        callHistoryAdapter = CallHistoryAdapter(callHistoryList, this.context)
        recyclerView.adapter = callHistoryAdapter
    }

    private suspend fun loadCallHistoryAsync(): List<PhoneCall2> {
        return withContext(Dispatchers.IO) {
            // Simulate data loading (e.g., from Call Log)
            loadCallHistory()
        }
    }

    private fun showLoading() {
        progressBar.visibility = View.VISIBLE
        recyclerView.visibility = View.GONE
    }

    private fun hideLoading() {
        progressBar.visibility = View.GONE
        recyclerView.visibility = View.VISIBLE
    }



    private fun loadCallHistory(): List<PhoneCall2> {
        var that = this.context
        val callHistoryList = mutableListOf<PhoneCall2>()

        try {
            val cursor: Cursor? = requireContext().contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.DATE, CallLog.Calls.TYPE),
                null,
                null,
                "${CallLog.Calls.DATE} DESC LIMIT 100"
            )

            cursor?.let {
                val numberIndex = it.getColumnIndex(CallLog.Calls.NUMBER)
                val dateIndex = it.getColumnIndex(CallLog.Calls.DATE)
                val typeIndex = it.getColumnIndex(CallLog.Calls.TYPE)

                if (numberIndex != -1 && dateIndex != -1) {
                    while (it.moveToNext()) {
                        val originalNumber = it.getString(numberIndex)
                        val number = if (that !== null) getContactName(that, originalNumber) else originalNumber
                        val phoneOrContact = if (number !== null) number else ""
                        val phoneNumber = if (originalNumber !== null) originalNumber else ""

                        //  Log.e("SimplyCall - CallHistory", "phoneOrContact ($phoneOrContact)")

                        val longTypeDate = it.getLongOrNull(dateIndex)
                        val date = if (longTypeDate !== null) formatTimestamp(longTypeDate) else ""
                        val callType = it.getIntOrNull(typeIndex)

                        // Map the integer type to a human-readable string
                        val callTypeStr = when (callType) {
                            null -> ""
                            CallLog.Calls.INCOMING_TYPE -> "Incoming"
                            CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
                            CallLog.Calls.MISSED_TYPE -> "Missed"
                            else -> "Unknown"
                        }
                        val call = PhoneCall2(phoneNumber, phoneOrContact, date, callTypeStr)
                        callHistoryList.add(call)
                    }
                } else {
                    Log.e("CallHistory", "Column not found")
                }
                it.close()
            }
        }
        catch (error: Error) {
            Log.e("SimplyCall - CallsHistoryFragment", "CallsHistoryFragment loadCallHistory Error ($error)")
        }


        return callHistoryList
    }

    private fun getContactName(context: Context, phoneNumber: String?): String? {
        if (phoneNumber === null || phoneNumber == "") return "Unknown Caller"
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber))
        val projection = arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME)

        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                return cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.PhoneLookup.DISPLAY_NAME))
            }
        }
        return phoneNumber
    }



    fun makeACall(context: Context, phoneNumber: String) {
/*        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager

      //  val phoneNumber = "tel:+1234567890" // Replace with the desired phone number
        val uri = Uri.parse(phoneNumber)

        val phoneAccountHandle: PhoneAccountHandle = telecomManager.phoneAccountHandles[0] // Get the default phone account
        val intent = Intent(Intent.ACTION_CALL, uri)
        intent.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, phoneAccountHandle)

        startActivity(intent) // Initiates the call*/
    }
}

fun formatTimestamp(timestamp: Long): String {
    // יצירת אובייקט של Calendar שמייצג את התאריך הנוכחי
    val now = Calendar.getInstance()

    // יצירת אובייקט Calendar מה-timestamp שהתקבל
    val callTime = Calendar.getInstance()
    callTime.timeInMillis = timestamp

    // חישוב הזמן שעבר מאז התאריך
    val diffInMillis = now.timeInMillis - callTime.timeInMillis

    // אם עברו פחות מ-24 שעות
    return if (diffInMillis < DateUtils.DAY_IN_MILLIS) {
        when {
            diffInMillis < DateUtils.HOUR_IN_MILLIS -> {
                val minutes = (diffInMillis / DateUtils.MINUTE_IN_MILLIS).toInt()
                "$minutes minutes ago" // החזרת הזמן בצורת "x minutes ago"
            }
            else -> {
                val hours = (diffInMillis / DateUtils.HOUR_IN_MILLIS).toInt()
                "$hours hours ago" // החזרת הזמן בצורת "x hours ago"
            }
        }
    } else {
        // אם עברו יותר מ-24 שעות, הצגת תאריך ושעה בפורמט לוקאלי
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) // פורמט לדוגמה
        dateFormat.format(callTime.time) // החזרת התאריך והשעה בפורמט לוקאלי
    }
}

data class PhoneCall2(val phoneNumber: String, val contactOrphoneNumber: String, val callDate: String, val type: String)

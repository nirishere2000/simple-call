package com.nirotem.simplecall

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.AudioManager.ROUTE_SPEAKER
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.Call
import android.telecom.InCallService
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.nirotem.simplecall.activities.EventScreenActivity
import com.nirotem.simplecall.managers.SoundPoolManager


class InCallServiceManager : InCallService() {

    private lateinit var activeCallDisplayManager: ActiveCallDisplayManager

    override fun onCreate() {
        super.onCreate()

        /**
         *  Although this happens on the main activity as well
         *  we don't know if it would run before an incoming call
         */
        SoundPoolManager.initialize(this)

        // Initialize the late init variable
        activeCallDisplayManager = ActiveCallDisplayManager()
    }

    override fun onCallAdded(call: Call) {
        val isOutgoing = OutgoingCall.isCalling
        val isCallWaiting = (OngoingCall.call !== null) && !isOutgoing
        val onCallAddedContext = this
        Log.d(
            "SimplyCall - InCallServiceManager",
            "onCallAdded (isCallWaiting = $isCallWaiting, OngoingCall.call = ${OngoingCall.call})"
        )

      //  setAudioRoute(ROUTE_SPEAKER)

        // Register a callback to monitor state changes
        val callCallback = object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                when (state) {
                    Call.STATE_RINGING -> {
                        Log.d(
                            "SimplyCall - InCallServiceManager",
                            "Call is ringing (onStateChanged)"
                        )
                        if (isOutgoing) {
                            playDefaultRingtone(onCallAddedContext)
                        }
                        // Launch your custom incoming call UI
                        //loadActivity(context, number, false)
                        // You can perform actions here when the call starts ringing
                    }

                    Call.STATE_ACTIVE -> {
                        Log.d("SimplyCall - InCallServiceManager", "Call is active (answered)")
                       // EventScreenActivity().finish() // Finish the call screen activity
                        //loadActivity(context, number, true)
                        // You can perform actions here when the call is answered
                        if (isOutgoing) {
                            OutgoingCall.otherCallerAnswered.value = true
                            OutgoingCall.wasAnswered = true
                            OutgoingCall.isCalling = false
                        }
                        else if (isCallWaiting) {
                            WaitingCall.wasAnswered = true
                            activeCallDisplayManager.handleAcceptCall(onCallAddedContext, isCallWaiting = false, isOutgoing = false)

                        }
                        else {
                            OngoingCall.wasAnswered = true
                            activeCallDisplayManager.handleAcceptCall(onCallAddedContext, isCallWaiting = false, isOutgoing = false)

                        }

                    }

                    Call.STATE_DISCONNECTED -> {
                        Log.d(
                            "SimplyCall - InCallServiceManager",
                            "Call is disconnected (call: ${WaitingCall.call?.details})"
                        )

                        // You can perform actions here when the call ends or is disconnected
                        // Unregister the callback
                        try {
                            if (isOutgoing) {
                                OutgoingCall.isCalling = false
                            }
/*                            WaitingCall.call = call
                            WaitingCall.wasAnswered = false
                            WaitingCall.onHold = false
                            WaitingCall.callWasDisconnectedManually = false
                            WaitingCall.phoneNumberOrContact = "+972543050638"
                            WaitingCall.conference = false
                            activeCallDisplayManager.handleIncomingCall(onCallAddedContext, true)*/
                            activeCallDisplayManager.handleDisconnect(
                                onCallAddedContext,
                                isCallWaiting,
                                isOutgoing
                            )
                        } catch (error: Error) {
                            Log.d(
                                "SimplyCall - InCallServiceManager",
                                "Call.STATE_DISCONNECTED -> { - Error ($error"
                            )
                        }
                    }

                    Call.STATE_HOLDING -> {
                        Log.d("SimplyCall - InCallServiceManager", "Call is on hold")
                        // Actions when call is on hold (optional)
                        // TODO: flag that call is on hold
                        if (isOutgoing) {
                            if (OutgoingCall.conference) {
                                OutgoingCall.call?.unhold() // In conference - no call should be on hold
                            }
                            else {
                                OutgoingCall.onHold = true
                            }
                        }
                        else if (isCallWaiting) {
                            if (WaitingCall.conference) {
                                WaitingCall.call?.unhold() // In conference - no call should be on hold
                            }
                            else {
                                WaitingCall.onHold = true
                            }

                        } else {
                            if (OngoingCall.conference) {
                                OngoingCall.call?.unhold() // In conference - no call should be on hold
                            }
                            else {
                                OngoingCall.onHold = true
                            }
                        }
                    }

                    else -> {
                        Log.d("SimplyCall - InCallServiceManager", "Call state changed: $state")
                    }
                }
            }
        }

        Log.d("SimplyCall - InCallServiceManager", "Call added4: ${call.details}")

        call.registerCallback(callCallback)

        handleIncomingCall(call, isCallWaiting, onCallAddedContext, isOutgoing)
    }

    override fun onCallRemoved(call: Call) {
        OngoingCall.call = null
    }

    fun playDefaultRingtone(context: Context) {
        val ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        val ringtone = RingtoneManager.getRingtone(context, ringtoneUri)
        ringtone.play()
    }

    private fun getContactName(context: Context, phoneNumber: String?): String? {
        if (phoneNumber === null) return "Unknown Caller"
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber))
        val projection = arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME)

        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                return cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.PhoneLookup.DISPLAY_NAME))
            }
        }
        return phoneNumber
    }

    // Main method to handle the incoming call
    private fun handleIncomingCall(call: Call, isCallWaiting: Boolean, context: Context, isOutgoing: Boolean) {
        val numberOrContact = call.details.handle?.schemeSpecificPart
        Log.d(
            "SimplyCall - InCallServiceManager",
            "Handle (${if (isOutgoing) "outgoing" else "incoming"} call from number ($call)"
        )

        if (isOutgoing) {
            OutgoingCall.call = call
            OutgoingCall.wasAnswered = false
            OutgoingCall.otherCallerAnswered.value = false
            OutgoingCall.onHold = false
            OutgoingCall.callWasDisconnectedManually = false
            OutgoingCall.phoneNumberOrContact = getContactName(context, numberOrContact)
            OutgoingCall.conference = false
            activeCallDisplayManager.handleOutgoingCall(context)
        }
        else if (!isCallWaiting) {
            OngoingCall.call = call
            OngoingCall.wasAnswered = false
            OngoingCall.onHold = false
            OngoingCall.callWasDisconnectedManually = false
            OngoingCall.phoneNumberOrContact = getContactName(context, numberOrContact)
            OngoingCall.conference = false
            activeCallDisplayManager.handleIncomingCall(context, false)
        } else { // call waiting
            /*
            * then OngoingCall.hangup()
            * and then OngoingCall.call = call
            */
            WaitingCall.call = call
            WaitingCall.wasAnswered = false
            WaitingCall.onHold = false
            WaitingCall.callWasDisconnectedManually = false
            WaitingCall.phoneNumberOrContact = getContactName(context, numberOrContact)
            WaitingCall.conference = false
            activeCallDisplayManager.handleIncomingCall(context, true)
        }


        Log.d(
            "SimplyCall - InCallServiceManager",
            "OngoingCall.call = ${OngoingCall.call?.details}, call = ${call.details}"
        )
    }

    // Requests overlay permission if not granted
    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${this.packageName}")
        )
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }

    // Shows the incoming call notification
    fun showIncomingCallNotification(context: Context, call: Call) {
        val intent = Intent(context, EventScreenActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent: PendingIntent =
            PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(context, "CALL_CHANNEL")
            .setContentTitle("Incoming Call")
            .setContentText("Tap to answer")
            .setSmallIcon(R.drawable.avatar_12)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = NotificationManagerCompat.from(context)
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        notificationManager.notify(1, notification)
    }

    // Create the notification channel for incoming call notifications (for API 26 and above)
    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "CALL_CHANNEL"
            val channelName = "Call Notifications"
            val importance = NotificationManager.IMPORTANCE_HIGH

            val channel = NotificationChannel(channelId, channelName, importance).apply {
                description = "Notifications for incoming calls"
            }

            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
}
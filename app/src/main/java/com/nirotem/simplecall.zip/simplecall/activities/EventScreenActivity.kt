package com.nirotem.simplecall.activities

//import android.media.MediaPlayer
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.telecom.TelecomManager
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.nirotem.simplecall.OngoingCall
import com.nirotem.simplecall.R
import com.nirotem.simplecall.WaitingCall
import com.nirotem.simplecall.ui.activeCall.ActiveCallFragment
import com.nirotem.simplecall.ui.conferenceCall.ConferenceCallFragment
import com.nirotem.simplecall.ui.incomingCall.IncomingCallFragment
import com.nirotem.simplecall.ui.waitingCall.WaitingCallFragment


class EventScreenActivity : AppCompatActivity() {

    private var currFragmentView: View? = null
    private var isSpeakerOn = false
  //  private lateinit var mediaPlayer: MediaPlayer
    private lateinit var callerNumberTextView: TextView
    private lateinit var activeFragment: androidx.fragment.app.Fragment

    val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d("SimplyCall - EventScreenActivity", "Received event: ${intent?.action}")
            if (intent?.action == "com.nirotem.simplecall.REMOVE_ACTIVE_CALL") {
                finish()
            }
            else if (intent?.action == "com.nirotem.simplecall.SWITCH_TO_ACTIVE_CALL") {
                val phoneContactOrNumber = intent.getStringExtra("phoneContactOrNumber")
                // Update your UI or data with the new call information
                val fragment =
                    // Load ActiveCallFragment if the call was answered
                    ActiveCallFragment().apply {
                        arguments = Bundle().apply {
                            putString("CALLER_NUMBER", phoneContactOrNumber)
                        }
                    }

                activeFragment = fragment

                // Replace the fragment container with the selected fragment
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit()
            }
            else if (intent?.action == "com.nirotem.simplecall.CHANGE_ACTIVE_CALL") {
                val phoneContactOrNumber = intent.getStringExtra("phoneContactOrNumber")
                // Update your UI or data with the new call information
                val fragment: ConferenceCallFragment? =
                    supportFragmentManager.findFragmentById(R.id.fragment_container) as ConferenceCallFragment?


                // שינוי הטקסט ב-TextView שבפרגמנט
                if (fragment != null && phoneContactOrNumber !== null) {
                    fragment.updateText(phoneContactOrNumber)
                }
            }
            else if (intent?.action == "com.nirotem.simplecall.SHOW_WAITING_CALL") {
                Log.d("SimplyCall - EventScreenActivity", "Received event: ${intent.action}")
                val phoneContactOrNumber = intent.getStringExtra("phoneContactOrNumber")
                val fragmentTransaction = supportFragmentManager.beginTransaction()

                val fragment =
                    // Load ActiveCallFragment if the call was answered
                    WaitingCallFragment().apply {
                        arguments = Bundle().apply {
                            putString("CALLER_NUMBER", phoneContactOrNumber)
                        }
                    }


                fragmentTransaction.setCustomAnimations(R.anim.slide_in_up, R.anim.slide_out_down)
                fragmentTransaction.replace(R.id.fragment_container, fragment)
                fragmentTransaction.commit()
            }
            else if (intent?.action == "ADD_CALLER") {
                val phoneContactOrNumber = intent.getStringExtra("phoneContactOrNumber")
                val fragmentTransaction = supportFragmentManager.beginTransaction()

                val fragment =
                    // For now only 2 callers (+user)
                    ConferenceCallFragment().apply {
                        arguments = Bundle().apply {
                            putString("CALLER_NUMBER", OngoingCall.phoneNumberOrContact)
                            putString("CALLER_NUMBER2", WaitingCall.phoneNumberOrContact)
                        }
                    }


                fragmentTransaction.setCustomAnimations(R.anim.slide_in_up, R.anim.slide_out_down)
                fragmentTransaction.replace(R.id.fragment_container, fragment)
                fragmentTransaction.commit()
            }
        }
    }

/*    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {

            Log.d("SimplyCall - EventScreenActivity", "Received event: ${intent?.action}")
            if (intent?.action == "REMOVE_ACTIVE_CALL") {
                finish()
            } else if (intent?.action == "CHANGE_ACTIVE_CALL") {
                val phoneContactOrNumber = intent.getStringExtra("phoneContactOrNumber")

            }
        }
    }*/

    /*    private var handler: Handler? = null
        private var runnable: Runnable? = null*/

    /*    private val broadcastReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val message = intent?.getStringExtra("message")
                // Handle the event and show a new screen (e.g., start a new Activity)
                if (message != null) {
                    showEventScreen(message)
                }
                showToast(context, "EventScreenActivity loaded (message $message)")
            }
        }*/

    // Helper function to show a toast message
    private fun showToast(context: Context?, message: String?) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("SimplyCall - EventScreenActivity", "Loading...")

        // Set the content view for the activity
        setContentView(R.layout.activity_event_screen)
       // callerNumberTextView = findViewById(R.id.text_incoming_call_contact)

        // Retrieve intent data
        val isCallWaiting = intent.getBooleanExtra("IS_CALL_WAITING", false)
        val callerNumber =  intent.getStringExtra("CALLER_NUMBER") ?: "Unknown Caller"
        val callerNumber2 = if (OngoingCall.conference) { intent.getStringExtra("CALLER_NUMBER1") ?: "Unknown Caller" } else ""
        val callAnswered = intent.getBooleanExtra("CALL_ANSWERED", false)
        val isCallOutgoing = intent.getBooleanExtra("IS_CALLING", false)

        // If this is the first creation, dynamically load the appropriate fragment
        if (savedInstanceState == null) {
            if (OngoingCall.conference) {
                val fragment = ConferenceCallFragment().apply {
                    arguments = Bundle().apply {
                        putString("CALLER_NUMBER", callerNumber)
                        putString("CALLER_NUMBER2", callerNumber2)
                    }
                }
                activeFragment = fragment

                // Replace the fragment container with the selected fragment
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit()
            }
            else {
                val fragment =
                    if (callAnswered || isCallOutgoing) { // if call answered we will show Active call screen even if it was call waiting
                        // Load ActiveCallFragment if the call was answered
                        ActiveCallFragment().apply {
                            arguments = Bundle().apply {
                                putString("CALLER_NUMBER", callerNumber)
                                putBoolean ("IS_CALLING", isCallOutgoing)
                            }
                        }
                    } else {
                        if (isCallWaiting)
                        /*                    // Load ActiveCallFragment if the call was answered
                    WaitingCallFragment().apply {
                        arguments = Bundle().apply {
                            putString("CALLER_NUMBER", callerNumber)
                        }
                    }*/
                            WaitingCallFragment.newInstance(callerNumber)
                        else {
                            // Load IncomingCallFragment if the call was not answered
                            IncomingCallFragment.newInstance(callerNumber)
                        }

                    }
                activeFragment = fragment

                // Replace the fragment container with the selected fragment
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit()
            }
        }

        Log.d(
            "SimplyCall - EventScreenActivity",
            "EventScreenActivity OnCreate (callAnswered = $callAnswered, callerNumber = $callerNumber)"
        )


        val intentFilter = IntentFilter("com.nirotem.simplecall.CHANGE_ACTIVE_CALL").apply {
            addAction("com.nirotem.simplecall.REMOVE_ACTIVE_CALL") // If you need multiple actions
            addAction("com.nirotem.simplecall.SWITCH_TO_ACTIVE_CALL")
            addAction("com.nirotem.simplecall.SHOW_WAITING_CALL")
        }

        ContextCompat.registerReceiver(
            this, // Context
            receiver, // The BroadcastReceiver
            intentFilter, // The IntentFilter
            ContextCompat.RECEIVER_NOT_EXPORTED // Export state
        )
    }

    override fun onStart() {
        super.onStart()
      //  val intentFilter = IntentFilter("com.example.CUSTOM_EVENT")
    }

    /*    override fun onStop() {
            super.onStop()
            // Unregister the BroadcastReceiver when the Activity stops
            //unregisterReceiver(broadcastReceiver)
        }*/

    @SuppressLint("MissingPermission", "NewApi")
    private fun acceptCall(context: Context) {
        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        telecomManager.acceptRingingCall()
        // triggerIncomingCallEvent(context, "acceptCall")
    }

    @SuppressLint("MissingPermission", "NewApi")
    private fun endCall(context: Context) {
        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        telecomManager.endCall()
        //triggerIncomingCallEvent(context, "rejectCall")
    }

    override fun onStop() {
        super.onStop()
        Log.d(
            "SimplyCall - EventScreenActivity",
            "Stopping sound"
        )
        // stopRingtone()  // Stop the ringtone when the activity stops
    }

    private fun startRingtone() {
        // Initialize the MediaPlayer with the MP3 file
       // mediaPlayer = MediaPlayer.create(this, R.raw.alternative_ringing_sound)
      //  mediaPlayer.isLooping = true
        // Start playback
      //  mediaPlayer.start()

        // Initialize the MediaPlayer with the MP3 file
        //     mediaPlayer = MediaPlayer.create(this, R.raw.welcome_instructions)

        // Start playback
        //     mediaPlayer.start()
    }

    private fun playSound() {
        // Optionally, reset MediaPlayer after playing
        //   mediaPlayer?.seekTo(0)  // Ensure it starts from the beginning each time
/*        Log.d(
            "SimplyCall - EventScreenActivity",
            "mediaPlayer.isPlaying = ${mediaPlayer?.isPlaying}"
        )*/

        // Play the sound (restart MediaPlayer each time)
        // mediaPlayer?.start()
    }

    private fun stopRingtone() {
        // Stop the handler from posting further runnables
        //   runnable?.let { handler?.removeCallbacks(it) }

        // Stop the media player when the activity stops
        //  mediaPlayer?.stop()
        //  mediaPlayer?.release()
        //  mediaPlayer = null
    }


    override fun onDestroy() {
        super.onDestroy()
      //  mediaPlayer.release()

        // Ensure the view is removed when the Activity is destroyed
        if (currFragmentView !== null && currFragmentView!!.isAttachedToWindow) {
            windowManager.removeView(currFragmentView)
            currFragmentView = null
        }
    }

    private fun toggleSpeakerphone() {
        isSpeakerOn = !isSpeakerOn
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            audioManager.mode = AudioManager.MODE_IN_CALL
            audioManager.isSpeakerphoneOn = isSpeakerOn // Fallback for older versions
            Log.d(
                "SimplyCall - EventScreenActivity",
                "Turn audioManager.isSpeakerphoneOn = $audioManager.isSpeakerphoneOn (isSpeakerOn = $isSpeakerOn)"
            )
        } else {
            modernToggleSpeakerphone(isSpeakerOn)
        }
    }

    @RequiresApi(Build.VERSION_CODES.S)
    fun modernToggleSpeakerphone(enable: Boolean) {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        if (enable) {
            Log.d(
                "SimplyCall - EventScreenActivity",
                "Turn audioManager true, $audioManager.isSpeakerphoneOn = $audioManager.isSpeakerphoneOn"
            )

            val devices = audioManager.availableCommunicationDevices
            val speakerDevice = devices.find { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            if (speakerDevice != null) {
                audioManager.setCommunicationDevice(speakerDevice)
            } else {
                Log.e("SpeakerControl", "Speakerphone device not found!")
            }
            Log.d(
                "SimplyCall - EventScreenActivity",
                "Turn audioManager true (after), $audioManager.isSpeakerphoneOn = $audioManager.isSpeakerphoneOn"
            )
        } else {
            Log.d(
                "SimplyCall - EventScreenActivity",
                "Turn audioManager false, $audioManager.isSpeakerphoneOn = $audioManager.isSpeakerphoneOn"
            )
            audioManager.clearCommunicationDevice()
            Log.d(
                "SimplyCall - EventScreenActivity",
                "Turn audioManager false (after), $audioManager.isSpeakerphoneOn = $audioManager.isSpeakerphoneOn"
            )
        }

    }

    private fun showDialog(title: String, msg: String) {
        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setPositiveButton("OK") { _, _ -> }
            .create()

        // Check if activity is running before showing
        if (!isFinishing) {
            dialog.show()
        }
    }
}

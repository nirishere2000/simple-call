package com.nirotem.simplecall.managers

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.Log
import com.nirotem.simplecall.R

object SoundPoolManager {
    var incomingCallWaitingSoundName: String = "incomingWaitingCallSound"
    var incomingCallSoundName: String = "incomingCallSound"
    var welcomeInstructionsSoundName: String = "welcomeInstructionsSound"
    var callDisconnectedSoundName: String = "callDisconnectedSound"
    var waitingCallDisconnectedSoundName: String = "waitingCallDisconnectedSound"
    var byeByeGreetingSoundName: String = "byeByeGreetingSound"

   var incomingCallSoundFileFinishedLoading = false

    private lateinit var soundPool: SoundPool
    private val soundMap: MutableMap<String, Int> = mutableMapOf()
    private val streamIds: MutableMap<String, Int> = mutableMapOf()
    private var incomingCallSoundId: Int = 0
    private var incomingCallSoundWasTriedToLoadBeforeInitCompleted = false

    /**
     * Initializes the SoundPoolManager with a SoundPool instance.
     * Call this once in the Application class or similar initialization code.
     */
    fun initialize(context: Context) {
        // incoming call might not be loaded before using - we we need to know
        if (!::soundPool.isInitialized) {
            incomingCallSoundFileFinishedLoading = false
            incomingCallSoundWasTriedToLoadBeforeInitCompleted = false
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            soundPool = SoundPool.Builder()
                .setAudioAttributes(audioAttributes)
                .setMaxStreams(5) // Maximum number of simultaneous streams
                .build()
        }
        if (!incomingCallSoundFileFinishedLoading) {
            soundPool.setOnLoadCompleteListener { soundPool, sampleId, status ->
                if (status == 0) { // 0 indicates success
                    //incomingCallSoundFileFinishedLoading
                    if (sampleId === incomingCallSoundId) {
                        incomingCallSoundFileFinishedLoading = true
                        if (incomingCallSoundWasTriedToLoadBeforeInitCompleted) {
                            playSound(incomingCallSoundName, true)
                        }
                    }
                    Log.d("SoundPoolManager", "Sound $sampleId loaded successfully")
                } else {
                    Log.e("SoundPoolManager", "Failed to load sound $sampleId")
                }
            }

            incomingCallSoundId = loadSound(context, incomingCallSoundName, R.raw.alternative_ringing_sound)
            loadSound(context, welcomeInstructionsSoundName, R.raw.welcome_instructions)
            loadSound(context, incomingCallWaitingSoundName, R.raw.incoming_call_waiting)
            loadSound(context, callDisconnectedSoundName, R.raw.call_disconnected)
            loadSound(context, waitingCallDisconnectedSoundName, R.raw.call_waiting_disconnected)
        }
    }

    /**
     * Loads a sound resource into the SoundPool and associates it with a name.
     * @param context The application context.
     * @param name The name of the sound to reference later.
     * @param resId The resource ID of the sound file (e.g., R.raw.sound1).
     */
    private fun loadSound(context: Context, name: String, resId: Int): Int {
        if (!::soundPool.isInitialized) throw IllegalStateException("SoundPoolManager not initialized")
        val soundId = soundPool.load(context, resId, 1)
        soundMap[name] = soundId
        Log.d("SimplyCall - SoundPoolManager", "Loaded $name sound file (sound id: $soundId)")
        return soundId
    }

    /**
     * Plays a sound by its name. If not found, the method will do nothing.
     * @param name The name of the sound to play.
     * @param loop Whether to loop the sound (-1 for infinite loop, 0 for no loop).
     */
    fun playSound(name: String, loop: Boolean = false) {
        if (!::soundPool.isInitialized) throw IllegalStateException("SoundPoolManager not initialized")
        val soundId = soundMap[name] ?: return
        val streamId = soundPool.play(soundId, 1f, 1f, 1, if (loop) -1 else 0, 1f)

        if (name === incomingCallSoundName && !incomingCallSoundFileFinishedLoading) {
            incomingCallSoundWasTriedToLoadBeforeInitCompleted = true
        }

        streamIds[name] = streamId
        Log.d("SimplyCall - SoundPoolManager", "Played $name sound file and got ID $streamId")
    }

    /**
     * Stops a sound that is currently playing by its name.
     * @param name The name of the sound to stop.
     */
    fun stopSound(name: String) {
        if (!::soundPool.isInitialized) throw IllegalStateException("SoundPoolManager not initialized")
        val streamId = streamIds[name] ?: return
        soundPool.stop(streamId)
        streamIds.remove(name)
    }

    /**
     * Releases the SoundPool resources. Should be called when the app is closing or the sounds are no longer needed.
     */
    fun release() {
        if (::soundPool.isInitialized) {
            soundPool.release()
        }
    }
}

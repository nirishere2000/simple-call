package com.nirotem.simplecall.ui.contacts

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.text.format.DateUtils
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import androidx.core.database.getIntOrNull
import androidx.core.database.getLongOrNull
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.nirotem.simplecall.OutgoingCall
import com.nirotem.simplecall.R
import com.nirotem.simplecall.adapters.ContactsAdapter
import com.nirotem.simplecall.ui.callsHistory.PhoneCall2
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.*

class ContactsFragment : Fragment(R.layout.fragment_contacts) {

    private lateinit var recyclerView: RecyclerView
    private lateinit var contactsAdapter: ContactsAdapter
    private lateinit var progressBar: ProgressBar

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        try {
            OutgoingCall.isCalling = false
            progressBar = view.findViewById(R.id.progressBar)
            recyclerView = view.findViewById(R.id.recyclerView)

            recyclerView.layoutManager = LinearLayoutManager(requireContext())

            // Load data asynchronously
            lifecycleScope.launch {
                showLoading() // Show ProgressBar
                val contactsList = loadCallHistoryAsync()
                setupRecyclerView(contactsList)
                hideLoading() // Hide ProgressBar
            }
        }
        catch (error: Error) {
            Log.e("SimplyCall - ContactsFragment", "ContactsFragment onViewCreated Error ($error)")
        }


        // Set adapter for RecyclerView
       // callHistoryAdapter = CallHistoryAdapter(loadCallHistory())
       // recyclerView.adapter = callHistoryAdapter


    }

    private fun setupRecyclerView(contactsList: List<Contact>) {
        contactsAdapter = ContactsAdapter(contactsList, this.context)
        recyclerView.adapter = contactsAdapter
    }

    private suspend fun loadCallHistoryAsync(): List<Contact> {
        return withContext(Dispatchers.IO) {
            // Simulate data loading (e.g., from Call Log)
            loadContacts()
        }
    }

    private fun showLoading() {
        progressBar.visibility = View.VISIBLE
        recyclerView.visibility = View.GONE
    }

    private fun hideLoading() {
        progressBar.visibility = View.GONE
        recyclerView.visibility = View.VISIBLE
    }

    private fun loadContacts(): List<Contact> {
        val contactsList = mutableListOf<Contact>()

        try {
            val uniqueContacts = mutableSetOf<String>()  // Set to store unique phone numbers
            val cursor = requireContext().contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(
                    ContactsContract.Contacts.DISPLAY_NAME, // Name
                    ContactsContract.CommonDataKinds.Phone.NUMBER, // Phone number
                    ContactsContract.CommonDataKinds.Event.START_DATE, // יום ההולדת נמצא כאן
                    ContactsContract.Contacts.PHOTO_URI, // Photo URI
                    ContactsContract.Contacts.STARRED, // Starred status (1 or 0)
                ),
                "${ContactsContract.Data.MIMETYPE} = ? AND ${ContactsContract.CommonDataKinds.Phone.HAS_PHONE_NUMBER} = 1",
                arrayOf(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC" // Sort by name
            )

            cursor?.use {
                while (it.moveToNext()) {
                    val contactName = it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                    val phoneNumber = it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))
                    val photoUri = it.getString(it.getColumnIndexOrThrow(ContactsContract.Contacts.PHOTO_URI))
                    val photoUriStr = if (photoUri !== null) photoUri else ""
                    val isStarred = it.getInt(it.getColumnIndexOrThrow(ContactsContract.Contacts.STARRED)) == 1
                    val birthdayLong = it.getLong(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Event.START_DATE))
                   val birthday = formatTimestamp(birthdayLong)

                    val contact = Contact(phoneNumber, contactName, birthday, isStarred, photoUriStr)

                    val shortPhoneNumber = phoneNumber.filter { it.isDigit() }

                    if (uniqueContacts.add(contactName+shortPhoneNumber)) {  // Adds only unique Contact + phone number
                        contactsList.add(contact)
                    }


                   // println("Contact: $name, Phone: $phoneNumber, Photo: $photoUri, Starred: $isStarred")
                }
            }
        }
        catch (error: Error) {
            Log.e("SimplyCall - ContactsFragment", "ContactsFragment loadContacts Error ($error)")
        }


        return contactsList
    }

    private fun getContactName(context: Context, phoneNumber: String?): String? {
        if (phoneNumber === null || phoneNumber == "") return "Unknown Caller"
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber))
        val projection = arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME)

        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                return cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.PhoneLookup.DISPLAY_NAME))
            }
        }
        return phoneNumber
    }



    fun makeACall(context: Context, phoneNumber: String) {
/*        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager

      //  val phoneNumber = "tel:+1234567890" // Replace with the desired phone number
        val uri = Uri.parse(phoneNumber)

        val phoneAccountHandle: PhoneAccountHandle = telecomManager.phoneAccountHandles[0] // Get the default phone account
        val intent = Intent(Intent.ACTION_CALL, uri)
        intent.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, phoneAccountHandle)

        startActivity(intent) // Initiates the call*/
    }
}

private fun formatTimestamp(timestamp: Long): String {
    // יצירת אובייקט של Calendar שמייצג את התאריך הנוכחי
    val now = Calendar.getInstance()

    // יצירת אובייקט Calendar מה-timestamp שהתקבל
    val callTime = Calendar.getInstance()
    callTime.timeInMillis = timestamp

    // חישוב הזמן שעבר מאז התאריך
    val diffInMillis = now.timeInMillis - callTime.timeInMillis

    // אם עברו פחות מ-24 שעות
    return if (diffInMillis < DateUtils.DAY_IN_MILLIS) {
        when {
            diffInMillis < DateUtils.HOUR_IN_MILLIS -> {
                val minutes = (diffInMillis / DateUtils.MINUTE_IN_MILLIS).toInt()
                "$minutes minutes ago" // החזרת הזמן בצורת "x minutes ago"
            }
            else -> {
                val hours = (diffInMillis / DateUtils.HOUR_IN_MILLIS).toInt()
                "$hours hours ago" // החזרת הזמן בצורת "x hours ago"
            }
        }
    } else {
        // אם עברו יותר מ-24 שעות, הצגת תאריך ושעה בפורמט לוקאלי
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) // פורמט לדוגמה
        dateFormat.format(callTime.time) // החזרת התאריך והשעה בפורמט לוקאלי
    }
}

data class Contact(val phoneNumber: String, val contactOrPhoneNumber: String, val contactBirthday: String, val isFavourite: Boolean, val photoUri: String)

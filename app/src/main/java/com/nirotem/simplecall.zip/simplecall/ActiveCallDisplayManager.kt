package com.nirotem.simplecall

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.provider.Settings
import android.telecom.Call
import android.telecom.VideoProfile
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.TextView
import com.nirotem.simplecall.activities.EventScreenActivity
import com.nirotem.simplecall.managers.SoundPoolManager

class ActiveCallDisplayManager {
    companion object {
       // var activeCall: Call? = null
        var canDrawOverlays: Boolean = false // settingCanDrawOverlaysPermissionGranted
    }

    private val windowManager: WindowManager by lazy {
        serviceContext?.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }
    private var incomingCallCustomView: View? = null
    private var waitingCallCustomView: View? = null
    private var activeCallCustomView: View? = null
    private var currentCallIsCallWaiting: Boolean = false
    private var serviceContext: Context? = null

    public fun handleAcceptCall(context: Context, isCallWaiting: Boolean, isOutgoing: Boolean) {
        if (isOutgoing) { // we did not set this info in handleIncoming
            serviceContext = context
            canDrawOverlays = Settings.canDrawOverlays(context)
            currentCallIsCallWaiting = isCallWaiting
        }
       // canDrawOverlays = Settings.canDrawOverlays(context)

        if (canDrawOverlays) {
            if (isOutgoing) {
                showCallScreenThroughActivity(context, isCallWaiting = false, isOutgoing = true) // show Outgoing number
            }
            else if (isCallWaiting) {
                if (WaitingCall.conference) { // Load Conference with both contacts (or numbers)
                    showCallScreenThroughActivity(context, isCallWaiting = true, isOutgoing = false) // load it as regular active call
                }
                else { // Just replace the active caller and show active call screen again
                    val originalWaitingCallContact = WaitingCall.phoneNumberOrContact
                    WaitingCall.phoneNumberOrContact = OngoingCall.phoneNumberOrContact
                    OngoingCall.phoneNumberOrContact = originalWaitingCallContact
                    val originalWaitingCallCall = WaitingCall.call
                    WaitingCall.call = OngoingCall.call
                    OngoingCall.call = originalWaitingCallCall
                    OngoingCall.onHold = false
                    WaitingCall.onHold = true
                    showCallScreenThroughActivity(context, isCallWaiting = true, isOutgoing = false) // load it as regular active call
                    // But now show small blob for the original Ongoing call if it's on hold. And let it be replaced and ended
                }
                //changeActivityCall(context, WaitingCall.phoneNumberOrContact) // The activity will know how to handle WaitingCall.conference
            }
            else { // load Active Call screen

                showCallScreenThroughActivity(context, isCallWaiting = false, isOutgoing = false)
                //switchToActiveCall(context, OngoingCall.phoneNumberOrContact )
            }

        } else {
            // Request permission if not granted and then show notification or custom UI
            //requestOverlayPermission()
            if (isCallWaiting) {
                // replace number in active fragment
              //  showCustomCallNotification(context, isCallWaiting)
            }
            showActiveCallScreenCustomNotification(context)
        }
    }


    // Shows custom UI for the active call using WindowManager if permission is not granted
    fun showActiveCallScreenCustomNotification(context: Context?) {
        // Set up WindowManager and LayoutParams

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.OPAQUE
        )

        val number = OngoingCall.call?.details?.handle?.schemeSpecificPart
        val customView = LayoutInflater.from(context).inflate(R.layout.fragment_incoming_call, null)
        customView.findViewById<TextView>(R.id.text_incoming_call_contact).text = number

        // Set up decline button click listener
        customView.findViewById<ImageButton>(R.id.declineButton).setOnClickListener {
            Log.d("SimplyCall - EventScreenActivity", "declineButton clicked")
            OngoingCall.call?.disconnect()
            windowManager.removeView(customView)
        }

        // Set up accept button click listener
        customView.findViewById<ImageButton>(R.id.acceptButton).setOnClickListener {
            handleAccpetCallByUser()
        }

        activeCallCustomView = customView

        // Add the custom view to WindowManager
        windowManager.addView(activeCallCustomView, layoutParams)

    }

    // Shows custom UI for the incoming call using WindowManager if permission is not granted
    fun showCustomCallNotification(context: Context, isCallWaiting: Boolean) {
        // Set up WindowManager and LayoutParams

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.OPAQUE
        )

        val number = OngoingCall.call?.details?.handle?.schemeSpecificPart
        val customView = LayoutInflater.from(context).inflate(R.layout.fragment_incoming_call, null)
        customView.findViewById<TextView>(R.id.text_incoming_call_contact).text = number

        // Set up decline button click listener
        customView.findViewById<ImageButton>(R.id.declineButton).setOnClickListener {
            Log.d("SimplyCall - EventScreenActivity", "declineButton clicked")
            stopRingtone(isCallWaiting)
            OngoingCall.call?.disconnect()

            windowManager.removeView(customView)
        }

        // Set up accept button click listener
        customView.findViewById<ImageButton>(R.id.acceptButton).setOnClickListener {
            handleAccpetCallByUser()
        }

        incomingCallCustomView = customView

        // Add the custom view to WindowManager
        windowManager.addView(incomingCallCustomView, layoutParams)
    }

    fun showCustomWaitingCallNotification(context: Context) {
        // Set up WindowManager and LayoutParams

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.OPAQUE
        )

        val number = WaitingCall.call?.details?.handle?.schemeSpecificPart
        val callWaitingCustomView =
            LayoutInflater.from(context).inflate(R.layout.fragment_waiting_call, null)
        callWaitingCustomView.findViewById<TextView>(R.id.text_incoming_call_contact).text = number

        // Set up decline button click listener
        callWaitingCustomView.findViewById<ImageButton>(R.id.declineButton).setOnClickListener {
            Log.d("SimplyCall - Call Waiting", "declineButton clicked")
            stopRingtone(true)
            WaitingCall.call?.disconnect()
            windowManager.removeView(callWaitingCustomView)
        }

        // Set up accept button click listener
        callWaitingCustomView.findViewById<ImageButton>(R.id.acceptButton).setOnClickListener {
            Log.d("SimplyCall - Call Waiting", "acceptButton clicked")
            handleAccpetCallWaitingByUser()
        }

        waitingCallCustomView = callWaitingCustomView

        // Add the custom view to WindowManager
        windowManager.addView(waitingCallCustomView, layoutParams)
    }

    private fun getSoundToPlayName(isCallWaiting: Boolean): String {
        val soundToPlay = if (isCallWaiting) SoundPoolManager.incomingCallWaitingSoundName else SoundPoolManager.incomingCallSoundName
        return soundToPlay
    }

    fun handleOutgoingCall(context: Context) {
        serviceContext = context
        canDrawOverlays = Settings.canDrawOverlays(context)
        currentCallIsCallWaiting = false

        //startRingtone(getSoundToPlayName(isCallWaiting))

        if (canDrawOverlays) {
            showCallScreenThroughActivity(context, isCallWaiting = false, isOutgoing = true) // load waiting call fragment

        } else {
            // Request permission if not granted and then show notification or custom UI
            //requestOverlayPermission()

        }
    }

    fun handleIncomingCall(context: Context, isCallWaiting: Boolean) {
        serviceContext = context
        canDrawOverlays = Settings.canDrawOverlays(context)
        currentCallIsCallWaiting = isCallWaiting

        startRingtone(getSoundToPlayName(isCallWaiting))

        if (canDrawOverlays) {
            if (isCallWaiting) {
                showCallScreenThroughActivity(context, true, false) // load waiting call fragment
            }
            else {
                showCallScreenThroughActivity(context, currentCallIsCallWaiting, false)  // Show activity directly if permission is granted
            }

        } else {
            // Request permission if not granted and then show notification or custom UI
            //requestOverlayPermission()
            if (isCallWaiting) {
                showCustomWaitingCallNotification(context)
            }
            else {
                showCustomCallNotification(context, currentCallIsCallWaiting)
            }
        }
    }

    fun handleDisconnect(context: Context, isCallWaiting: Boolean, isOutgoing: Boolean) {
        stopRingtone(isCallWaiting)
        if (!isCallWaiting) { // also for outgoing call for now
            if (!OngoingCall.callWasDisconnectedManually) {
                SoundPoolManager.playSound(SoundPoolManager.callDisconnectedSoundName, false)
            }
        }
        else {
            if (!OngoingCall.callWasDisconnectedManually) {
                SoundPoolManager.playSound(SoundPoolManager.waitingCallDisconnectedSoundName, false)
            }
        }

        // Remove activity directly if permission is granted
        // if (call was already answered we need to remove Active Call fragment)
        // if call is call waiting and we did not initiated the call we need to remove waiting call fragment

        // Request permission if not granted and then show notification or custom UI
        //requestOverlayPermission()
        if (isOutgoing) {
            if (OutgoingCall.wasAnswered) {
                if (OutgoingCall.onHold) {
                    // we just showed small icon for it so remove it
                } else {
                    if (canDrawOverlays) {
                        if (WaitingCall.onHold) { // then we need to get it back to active call
                            // load active call screen
                            changeActivityCall(context, WaitingCall.phoneNumberOrContact)
                        } else {
                            removeActivity(context)
                        }
                    } else {
                        if (activeCallCustomView !== null) { // call was the active call
                            windowManager.removeView(activeCallCustomView)
                            activeCallCustomView = null
                        }

                    }
                }
            }
            else { // Call was not answered yet - we just remove the Incoming Call UI
                if (canDrawOverlays) {

                    removeActivity(context)
                }
                else {
                    windowManager.removeView(incomingCallCustomView)
                    incomingCallCustomView = null
                }
            }
        }
        else if (isCallWaiting) {
            if (WaitingCall.wasAnswered) {
                if (WaitingCall.onHold) {
                    // we just showed small icon for it so remove it
                } else {
                    if (canDrawOverlays) {
                        if (OngoingCall.onHold) { // then we need to get it back to active call
                            // load active call screen
                            changeActivityCall(context, OngoingCall.phoneNumberOrContact)
                        } else {
                            removeActivity(context)
                        }
                    } else {
                        if (activeCallCustomView !== null) { // waiting call was the active call (although it's still in the waiting call object)
                            windowManager.removeView(activeCallCustomView)
                            activeCallCustomView = null
                        }
                    }
                }
            } else { // call was not answered yet, just remove waiting call screen
                if (canDrawOverlays) {
                    Log.d("SimplyCall - ActiveCallDisplayManager", "Disconnect - canDrawOverlays -> removeActivity(context)")
                    removeActivity(context)
                } else {
                    if (waitingCallCustomView !== null) {
                        windowManager.removeView(waitingCallCustomView)
                        waitingCallCustomView = null
                    }
                }

            }
        }
        else {
            if (OngoingCall.wasAnswered) {
                if (OngoingCall.onHold) {
                    // we just showed small icon for it so remove it
                } else {
                    if (canDrawOverlays) {
                        if (WaitingCall.onHold) { // then we need to get it back to active call
                            // load active call screen
                            changeActivityCall(context, WaitingCall.phoneNumberOrContact)
                        } else {
                            removeActivity(context)
                        }
                    } else {
                        if (activeCallCustomView !== null) { // call was the active call
                            windowManager.removeView(activeCallCustomView)
                            activeCallCustomView = null
                        }

                    }
                }
            }
            else { // Call was not answered yet - we just remove the Incoming Call UI
                if (canDrawOverlays) {

                    removeActivity(context)
                }
                else {
                    windowManager.removeView(incomingCallCustomView)
                    incomingCallCustomView = null
                }
            }
        }
    }

    private fun switchToActiveCall(context: Context, phoneContactOrNumber: String?) {
        sendBroadcastToActivity(
            context,
            "com.nirotem.simplecall.SWITCH_TO_ACTIVE_CALL",
            "phoneContactOrNumber",
            phoneContactOrNumber
        )
    }




    private fun switchToConferenceScreen(context: Context) {
        sendBroadcastToActivity(
            context,
            "com.nirotem.simplecall.ADD_CALLER",
            null,
            null
        )
    }

    private fun showCallWaiting(context: Context, phoneContactOrNumber: String?) {
        sendBroadcastToActivity(
            context,
            "com.nirotem.simplecall.SHOW_WAITING_CALL",
            "phoneContactOrNumber",
            phoneContactOrNumber
        )
    }

    private fun changeActivityCall(context: Context, callContactOrNumber: String?) {
        sendBroadcastToActivity(
            context,
            "com.nirotem.simplecall.CHANGE_ACTIVE_CALL",
            "phoneContactOrNumber",
            callContactOrNumber
        )
    }

    private fun removeActivity(context: Context) {
        Log.d("SimplyCall - ActiveCallDisplayManager", "removeActivity: send REMOVE_ACTIVE_CALL")
        sendBroadcastToActivity(context, "com.nirotem.simplecall.REMOVE_ACTIVE_CALL", null, null)
    }

    private fun sendBroadcastToActivity(
        context: Context,
        event: String,
        strParameter: String?,
        strParameterValue: String?
    ) {
        val intent = Intent(event)
        if (strParameter !== null) {
            intent.putExtra(strParameter, strParameterValue)
        }
        context.sendBroadcast(intent)
    }

    // Checks if the call supports video
    private fun supportsVideoCall(): Boolean {
        val capabilities = OngoingCall.call?.details?.callCapabilities
        return (capabilities?.and(Call.Details.CAPABILITY_SUPPORTS_VT_LOCAL_TX) != 0) &&
                (capabilities?.and(Call.Details.CAPABILITY_SUPPORTS_VT_LOCAL_RX) != 0)
    }

    private fun showCallScreenThroughActivity(context: Context, isCallWaiting: Boolean, isOutgoing: Boolean) {
        val intent = Intent(context, EventScreenActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        var phoneNumberOrContact = OngoingCall.phoneNumberOrContact
        var phoneNumberOrContact2 = WaitingCall.phoneNumberOrContact
        var callWasAnswered = OngoingCall.wasAnswered
        if (isOutgoing) {
            phoneNumberOrContact = OutgoingCall.phoneNumberOrContact
            callWasAnswered = OutgoingCall.wasAnswered // WaitingCall.wasAnswered
            if (!OutgoingCall.wasAnswered) {
                intent.putExtra("IS_CALLING", true)
            }
        }
        else if (isCallWaiting && !WaitingCall.wasAnswered) {
            phoneNumberOrContact = WaitingCall.phoneNumberOrContact
            callWasAnswered = false // WaitingCall.wasAnswered
        } // Otherwise we replaced the Ongoing and WaitingCall contacts - so now WaitingCall is on hold

        if (WaitingCall.conference) {
            intent.putExtra("CALLER_NUMBER2", phoneNumberOrContact2)
        }

        intent.putExtra("CALLER_NUMBER", phoneNumberOrContact)
        intent.putExtra("CALL_ANSWERED", callWasAnswered)
        intent.putExtra("IS_CALL_WAITING", isCallWaiting)
        context.startActivity(intent) // Take over the screen with activity, and this ser
    }


    private fun handleAccpetCallByUser() {
        Log.d("SimplyCall - EventScreenActivity", "callAccepted!")
        val videoState = if (supportsVideoCall()) {
            VideoProfile.STATE_BIDIRECTIONAL
        } else {
            VideoProfile.STATE_AUDIO_ONLY
        }
        OngoingCall.answer(videoState)
        stopRingtone(false)
        if (!canDrawOverlays && serviceContext !== null) { // otherwise activity already loaded and will handle this
            windowManager.removeView(incomingCallCustomView)


           // showActiveCallScreenCustomNotification(serviceContext)
        }
    }

    private fun handleAccpetCallWaitingByUser() {
        Log.d("SimplyCall - EventScreenActivity", "callAccepted!")
        // Sound: Stop waiting call sound
        stopRingtone(true)

        val videoState = if (supportsVideoCall()) {
            VideoProfile.STATE_BIDIRECTIONAL
        } else {
            VideoProfile.STATE_AUDIO_ONLY
        }
        WaitingCall.call?.answer(videoState)
        // OngoingCall should go to hold
        if (!canDrawOverlays) { // otherwise activity already loaded and will handle this
            windowManager.removeView(waitingCallCustomView)
            showActiveCallScreenCustomNotification(serviceContext)
        }
    }

    private fun startRingtone(sound: String) {
        // Initialize the MediaPlayer with the MP3 file
        SoundPoolManager.playSound(sound, true)
    }

    private fun stopRingtone(isCallWaiting: Boolean) {
        val soundToStop = getSoundToPlayName(isCallWaiting)
        SoundPoolManager.stopSound(soundToStop)
    }

    protected fun finalize() {
        stopRingtone(false)
        stopRingtone(true)
    }
}
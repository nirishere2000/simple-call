package com.nirotem.simplecall.ui.singleCallHistory

import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.nirotem.simplecall.R
import com.nirotem.simplecall.ui.callsHistory.PhoneCall2
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class SingleCallHistoryFragment : Fragment(R.layout.fragment_calls_history) {

    private lateinit var contactName: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var callButton: Button
    private lateinit var backButton: Button

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        contactName = view.findViewById(R.id.contactName)
        recyclerView = view.findViewById(R.id.contactHistoryRecyclerView)
        callButton = view.findViewById(R.id.callButton)
        backButton = view.findViewById(R.id.backButton)

       // val args = SingleCallHistoryFragmentArgs.fromBundle(requireArguments())
        contactName.text = "Contact ad" // args.contactName

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        //recyclerView.adapter = CallHistoryAdapter(getDummyHistory("2332423"))

        callButton.setOnClickListener {
            // Navigate to Outgoing Call Screen
        }

        backButton.setOnClickListener {
            findNavController().popBackStack()
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun getDummyHistory(phoneNumber: String): List<PhoneCall2> {
        val currentDateTime = LocalDateTime.now()
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        val formattedDateTime = currentDateTime.format(formatter)

        return listOf(
          //  PhoneCall2(phoneNumber, formattedDateTime),
            //PhoneCall2("John Doe", formattedDateTime)

                   // PhoneCall2("John Doe", phoneNumber, "Outgoing"),
       // PhoneCall2("John Doe", phoneNumber, "Missed", missed = true
        )
    }
}
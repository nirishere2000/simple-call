package com.nirotem.simplecall.ui.activeCall

import android.content.Context
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.INVISIBLE
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageButton
import androidx.appcompat.widget.AppCompatTextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.nirotem.simplecall.OngoingCall
import com.nirotem.simplecall.OutgoingCall
import com.nirotem.simplecall.R
import com.nirotem.simplecall.databinding.FragmentActiveCallBinding

class ActiveCallFragment : Fragment() {
    private lateinit var textViewPhoneNumber: TextView
    private var isSpeakerOn: Boolean = false
    private var _binding: FragmentActiveCallBinding? = null
    private var isOutgoingCall = false

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Get the phone number from the arguments (passed from the activity)
        val phoneNumber = arguments?.getString("CALLER_NUMBER") ?: "Unknown Caller"
        var isCalling = arguments?.getBoolean ("IS_CALLING", false) ?: false
        if (isCalling) { // animate and show Calling text
            isOutgoingCall = true

        }

        // Use ViewModelFactory to create the ViewModel
        val activeCallViewModel = ViewModelProvider(
            this,
            ActiveCallViewModel.ActiveCallViewModelFactory(phoneNumber)
        ).get(ActiveCallViewModel::class.java)

        _binding = FragmentActiveCallBinding.inflate(inflater, container, false)
        val root: View = binding.root

        if (isOutgoingCall) {
            val outgoingCallCallingText =
                binding.root.findViewById<AppCompatTextView>(R.id.text_calling)
            val text = outgoingCallCallingText.text
            val handler = Handler(Looper.getMainLooper())
            outgoingCallCallingText.text = ""
            for (i in text.indices) {
                handler.postDelayed({
                    outgoingCallCallingText.text = outgoingCallCallingText.text.toString() + text[i]
                }, (50 * i).toLong())
            }
           // waveAnimation(outgoingCallCallingText)

            val textShaderIvoryLightBlue = LinearGradient(
                0f, 0f,
                outgoingCallCallingText.paint.measureText(outgoingCallCallingText.text.toString()),
                outgoingCallCallingText.textSize,
                intArrayOf(Color.parseColor("#FFFFF0"), Color.parseColor("#ADD8E6")), // Ivory and Light Blue
                null,
                Shader.TileMode.CLAMP
            )
            outgoingCallCallingText.paint.shader = textShaderIvoryLightBlue
        }

        textViewPhoneNumber = binding.textActiveCallContact
        updateText(phoneNumber)
        // textViewContactName = binding.textIncomingCallLabel

        /*        val textView: TextView = binding.textIncomingCallContact
                incomingCallViewModel.text.observe(viewLifecycleOwner) {
                    textView.text = phoneNumber
                }*/
        val declineButton = binding.root.findViewById<AppCompatImageButton>(R.id.declineButton)
        // waveAnimation(textViewPhoneNumber)

        declineButton.setOnClickListener { // decline call and hide screen
            Log.d("SimplyCall - ActiveCallFragment", "declineButton clicked - Fragment (isOutgoingCall = $isOutgoingCall)")
            if (isOutgoingCall) {
                OutgoingCall.hangup()
            }
            else {
                OngoingCall.hangup()
            }
            exitTransition = android.transition.Fade() // Add fade effect
            parentFragmentManager.beginTransaction()
                .remove(this)
                .commit()
        }
        val speakerButton = binding.root.findViewById<AppCompatImageButton>(R.id.speakerButton)
        if (isSpeakerphoneOn(this.requireContext())) {
            speakerButton.setImageResource(R.drawable.speaker_on)
        }

        speakerButton.setOnClickListener { // decline call and hide screen
            if (this.context !== null) {
                //   Log.d("SimplyCall - ActiveCallFragment", "set Speaker before: (isSpeakerOn = $isSpeakerOn), (isSpeakerphoneOn(this.requireContext()) = ${isSpeakerphoneOn(this.requireContext())}")
                if (isSpeakerOn) {
                    setSpeakerphone(this.requireContext(), false)
                    speakerButton.setImageResource(R.drawable.speaker)
                } else {
                    setSpeakerphone(this.requireContext(), true)
                    speakerButton.setImageResource(R.drawable.speaker_on)
                }
                // Log.d("SimplyCall - ActiveCallFragment", "set Speaker after: (isSpeakerOn = $isSpeakerOn), (isSpeakerphoneOn(this.requireContext()) = ${isSpeakerphoneOn(this.requireContext())}")
            }
        }

        // Observe the wasAnswered property
        OutgoingCall.otherCallerAnswered.observe(viewLifecycleOwner) { callWasAnswered ->
            if (callWasAnswered) {
                isCalling = false
                val outgoingCallCallingText =
                    binding.root.findViewById<AppCompatTextView>(R.id.text_calling)
                outgoingCallCallingText.visibility = INVISIBLE
                // Handle the case when the call was answered
               // Toast.makeText(requireContext(), "Call was answered!", Toast.LENGTH_SHORT).show()
            } else {
                // Handle the case when the call was not answered
               // Toast.makeText(requireContext(), "Waiting for call to be answered.", Toast.LENGTH_SHORT).show()
            }
        }

        return root
    }

    override fun onDetach() {
        super.onDetach()
        requireActivity().finish()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    fun updateText(newPhoneOrContact: String) {
        val contactLabel =
            binding.root.findViewById<AppCompatTextView>(R.id.text_active_call_contact)
        contactLabel.text = newPhoneOrContact
        //textViewPhoneNumber = newPhoneOrContact
    }

    private fun setSpeakerphone(context: Context, enable: Boolean) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.requestAudioFocus(
            null, // ניתן להוסיף Listener לשינויים אם צריך
            AudioManager.STREAM_VOICE_CALL,
            AudioManager.AUDIOFOCUS_GAIN
        )
        audioManager.setMode(AudioManager.MODE_IN_CALL)
        //audioManager.isSpeakerphoneOn = true

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val speakerphone = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            if (enable && speakerphone != null) {
                audioManager.setCommunicationDevice(speakerphone)
            } else {
                audioManager.clearCommunicationDevice()
            }
        } else { // Older versions
            audioManager.isSpeakerphoneOn = enable
        }
        isSpeakerOn = enable
    }

    fun isSpeakerphoneOn(context: Context): Boolean {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager


        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // בודקים אם הספיקר מוגדר כמכשיר התקשורת הפעיל
            val currentDevice = audioManager.communicationDevice
            currentDevice?.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
        } else {
            // בגרסאות ישנות יותר, משתמשים במאפיין הישן
            audioManager.isSpeakerphoneOn
        }
    }

    fun waveAnimation(textView: TextView) {
        fun waveAnimation(textView: TextView) {
// In the layout, use a shader for the TextView
// In the layout, use a shader for the TextView
            // val textView = this.findViewById<TextView>(R.id.textView)

            val textShader = LinearGradient(
                0f, 0f, textView.paint.measureText(textView.text.toString()), textView.textSize,
                intArrayOf(Color.RED, Color.BLUE, Color.GREEN),
                null,
                Shader.TileMode.CLAMP
            )
            textView.paint.shader = textShader

            // val textView = findViewById<TextView>(R.id.textView)
            /*    val colorAnimator = ObjectAnimator.ofArgb(textView, "textColor", Color.RED, Color.BLUE)
                colorAnimator.duration = 1000
                colorAnimator.repeatMode = ValueAnimator.REVERSE
                colorAnimator.repeatCount = ValueAnimator.INFINITE
                colorAnimator.start()*/


        }
    }


}
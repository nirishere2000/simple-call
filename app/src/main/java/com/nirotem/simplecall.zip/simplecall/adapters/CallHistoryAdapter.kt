package com.nirotem.simplecall.adapters

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.view.LayoutInflater
import android.view.View
import android.view.View.INVISIBLE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.core.net.toUri

import androidx.recyclerview.widget.RecyclerView
import com.nirotem.simplecall.OutgoingCall
import com.nirotem.simplecall.R
import com.nirotem.simplecall.ui.callsHistory.PhoneCall2

class CallHistoryAdapter(private val callHistory: List<PhoneCall2>, context: Context?) : RecyclerView.Adapter<CallHistoryAdapter.CallViewHolder>() {

    private val fragmentContext = context

    class CallViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val contactName: TextView = itemView.findViewById(R.id.contactName)
    //    val callTypeIcon: ImageView = itemView.findViewById(R.id.callTypeIcon)
        val callDate: TextView = itemView.findViewById(R.id.callDate)
        val missedIndicator: ImageView = itemView.findViewById(R.id.missedIndicator) // A red dot or similar
        val callButton: ImageView = itemView.findViewById(R.id.callButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CallViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_call, parent, false)
        return CallViewHolder(view)
    }

    private fun makeCall(callPhoneNumber: String) {
        //   if (checkSelfPermission(this, CALL_PHONE) == PERMISSION_GRANTED) {
        //val uri = "tel:${+97237537900}".toUri()

        val uri = "tel:${callPhoneNumber}".toUri()

        if (fragmentContext != null) {
            OutgoingCall.isCalling = true

            startActivity(fragmentContext, Intent(Intent.ACTION_CALL, uri), null)
        }
        //     } else {
        //        requestPermissions(this, arrayOf(CALL_PHONE), REQUEST_PERMISSION)
        //      }


    }

    fun waveAnimation(textView: TextView) {
// In the layout, use a shader for the TextView
// In the layout, use a shader for the TextView
    // val textView = this.findViewById<TextView>(R.id.textView)

    val textShader = LinearGradient(
        0f, 0f, textView.paint.measureText(textView.text.toString()), textView.textSize,
        intArrayOf(Color.RED, Color.BLUE, Color.GREEN),
        null,
        Shader.TileMode.CLAMP
    )
    textView.paint.shader = textShader

    // val textView = findViewById<TextView>(R.id.textView)
/*    val colorAnimator = ObjectAnimator.ofArgb(textView, "textColor", Color.RED, Color.BLUE)
    colorAnimator.duration = 1000
    colorAnimator.repeatMode = ValueAnimator.REVERSE
    colorAnimator.repeatCount = ValueAnimator.INFINITE
    colorAnimator.start()*/


    }


    override fun onBindViewHolder(holder: CallViewHolder, position: Int) {
        val call = callHistory[position]
        holder.contactName.text = call.contactOrphoneNumber
        holder.callButton.visibility = if (call.contactOrphoneNumber === "Unknown Caller") INVISIBLE else VISIBLE
        if (call.phoneNumber !== null && call.phoneNumber !== "") {

            holder.callButton.setOnClickListener( {

              makeCall(call.phoneNumber)
            })
        }


    //    holder.callType.text = "Incoming" // call.type
        holder.callDate.text = call.callDate



        // Set call type icon
        when (call.type) {
            "Incoming" -> holder.missedIndicator.setImageResource(android.R.drawable.sym_call_incoming)
            "Outgoing" -> holder.missedIndicator.setImageResource(android.R.drawable.sym_call_outgoing)
            "Missed" -> holder.missedIndicator.setImageResource(android.R.drawable.sym_call_missed)
        }
       // holder.callTypeIcon.setImageResource(R.drawable.speaker_on)

        // Show or hide missed call indicator
       // holder.missedIndicator.visibility = if (call.missed) View.VISIBLE else View.GONE
       // holder.missedIndicator.visibility = View.VISIBLE
    }

    override fun getItemCount(): Int = callHistory.size
}

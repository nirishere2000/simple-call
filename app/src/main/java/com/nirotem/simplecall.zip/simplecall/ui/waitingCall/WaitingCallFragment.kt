package com.nirotem.simplecall.ui.waitingCall

import android.os.Bundle
import android.telecom.Call
import android.telecom.VideoProfile
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatImageButton
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.nirotem.simplecall.OngoingCall
import com.nirotem.simplecall.R
import com.nirotem.simplecall.WaitingCall
import com.nirotem.simplecall.databinding.FragmentWaitingCallBinding
import com.nirotem.simplecall.managers.SoundPoolManager

class WaitingCallFragment : Fragment() {
    private lateinit var textViewPhoneNumber: TextView
    private lateinit var textViewContactName: TextView
    private var _binding: FragmentWaitingCallBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    companion object {
        private const val ARG_DATA = "CALLER_NUMBER"

        fun newInstance(phoneNumberOrContact: String): WaitingCallFragment {
            val fragment = WaitingCallFragment()
            val args = Bundle().apply {
                putString(ARG_DATA, phoneNumberOrContact)
            }
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Get the phone number from the arguments (passed from the activity)
        val phoneNumber = arguments?.getString("CALLER_NUMBER") ?: "Unknown Caller"

        // Use ViewModelFactory to create the ViewModel
        val waitingCallViewModel = ViewModelProvider(this,
            WaitingCallViewModel.WaitingCallViewModelFactory(phoneNumber)
        ).get(WaitingCallViewModel::class.java)

        _binding = FragmentWaitingCallBinding.inflate(inflater, container, false)
        val root: View = binding.root

        textViewPhoneNumber = binding.textIncomingCallContact
        textViewContactName = binding.textIncomingCallLabel

        val textView: TextView = binding.textIncomingCallContact
        waitingCallViewModel.text.observe(viewLifecycleOwner) {
            textView.text = phoneNumber
        }
        val declineButton = binding.root.findViewById<AppCompatImageButton>(R.id.declineButton)

        declineButton.setOnClickListener { // decline call and hide screen
            //Toast.makeText(context, "Hello", Toast.LENGTH_SHORT).show()
            Log.d("SimplyCall - IncomingWaitingCallFragment", "callRejected button clicked - Fragment")

            stopRingtone(true)
            exitTransition = android.transition.Fade() // Add fade effect
            parentFragmentManager.beginTransaction()
                .remove(this)
                .commit()

/*            incomingCallViewModel.rejectIncomingCall()
            parentFragmentManager.beginTransaction()
                .remove(this)  // Hide the current fragment
                .commit()*/
        }
        val acceptButton = binding.root.findViewById<AppCompatImageButton>(R.id.acceptButton)
        acceptButton.setOnClickListener { // decline call and hide screen

            Log.d("SimplyCall - IncomingWaitingCallFragment", "call was accepted by user! Swiping calls")
            val videoState = if (supportsVideoCall()) {
                VideoProfile.STATE_BIDIRECTIONAL
            } else {
                VideoProfile.STATE_AUDIO_ONLY
            }
            stopRingtone(false)
            WaitingCall.answer(videoState)

// replace number and play call replaced phone sound

            exitTransition = android.transition.Fade() // Add fade effect
            parentFragmentManager.beginTransaction()
                .remove(this)  // Hide the current fragment
                .commit()
        }
        val conferenceCallButton = binding.root.findViewById<AppCompatButton>(R.id.conferenceButton)
        conferenceCallButton.setOnClickListener { // add call and switch to Conference screen

            Log.d("SimplyCall - IncomingWaitingCallFragment", "call was accepted by user! Swiping calls")
            val videoState = if (supportsVideoCall()) {
                VideoProfile.STATE_BIDIRECTIONAL
            } else {
                VideoProfile.STATE_AUDIO_ONLY
            }
            stopRingtone(false)
            WaitingCall.conference = true
            OngoingCall.conference = true
            WaitingCall.answer(videoState)

// replace number and play call replaced phone sound

            exitTransition = android.transition.Fade() // Add fade effect
            parentFragmentManager.beginTransaction()
                .remove(this)  // Hide the current fragment
                .commit()
        }
        return root
    }

    override fun onDetach() {
        super.onDetach()
        requireActivity().finish()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getSoundToPlayName(isCallWaiting: Boolean): String {
        val soundToPlay = if (isCallWaiting) SoundPoolManager.incomingCallWaitingSoundName else SoundPoolManager.incomingCallSoundName
        return soundToPlay
    }

    private fun stopRingtone(isCallWaiting: Boolean) {
        val soundToStop = getSoundToPlayName(isCallWaiting)
        SoundPoolManager.stopSound(soundToStop)
    }

    // Checks if the call supports video
    private fun supportsVideoCall(): Boolean {
        val capabilities = OngoingCall.call?.details?.callCapabilities
        return (capabilities?.and(Call.Details.CAPABILITY_SUPPORTS_VT_LOCAL_TX) != 0) &&
                (capabilities?.and(Call.Details.CAPABILITY_SUPPORTS_VT_LOCAL_RX) != 0)
    }
}
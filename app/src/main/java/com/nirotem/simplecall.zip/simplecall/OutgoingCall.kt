package com.nirotem.simplecall

import android.telecom.Call
import android.telecom.VideoProfile
import android.util.Log
import androidx.lifecycle.MutableLiveData

//import io.reactivex.subjects.BehaviorSubject
//import timber.log.Timber

object OutgoingCall {
    //val state: BehaviorSubject<Int> = BehaviorSubject.create()

/*    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, newState: Int) {
           // Timber.d(call.toString())
           // state.onNext(newState)
            Log.d("SimplyCall - OngoingCall", "OngoingCall - onStateChanged: ${call.state}")
        }
    }*/

    var wasAnswered: Boolean = false
    var otherCallerAnswered = MutableLiveData(false)
    var onHold: Boolean = false // was answered (not ringing) but on hold for other call
    var phoneNumberOrContact: String? = "Unknown Caller"
    var callWasDisconnectedManually = false
    var call: Call? = null
    var conference = false
    var isCalling = false

/*    var call: Call? = null
        set(value) {
            field?.unregisterCallback(callback)
            value?.let {
                it.registerCallback(callback)
               // state.onNext(it.state)
            }
            field = value
        }*/

    fun hangup() {
        callWasDisconnectedManually = true
        Log.d("SimplyCall - OutgoingCall", "OutgoingCall - hangup: ${call?.details}")
        call?.disconnect()
        call = null
    }
}
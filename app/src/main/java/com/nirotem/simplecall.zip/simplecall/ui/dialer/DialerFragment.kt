package com.nirotem.simplecall.ui.dialer

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageButton
import androidx.appcompat.widget.AppCompatTextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.nirotem.simplecall.OngoingCall
import com.nirotem.simplecall.R
import com.nirotem.simplecall.databinding.FragmentActiveCallBinding
import com.nirotem.simplecall.ui.callsHistory.CallsHistoryViewModel

class DialerFragment : Fragment(R.layout.fragment_dialer) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val buttons = listOf(
            view.findViewById<ImageView>(R.id.key1),
          //  view.findViewById<Button>(R.id.button2),
            // Add references for all dialer buttons
        )
        val key2 = view.findViewById<ImageView>(R.id.key2)

        key2.setOnClickListener {
            // Handle button click
            //  val digit = button.text.toString()
            clickKey(2)
            Log.d("SimplyCall - DialerFragment", "DialerFragment digit 2 clicked")
        }

        buttons.forEach { button ->
            button.setOnClickListener {
                // Handle button click
              //  val digit = button.text.toString()
                clickKey(10)

            }
        }
    }

    private fun clickKey(keyNumber: Int) {
        Log.d("SimplyCall - DialerFragment", "DialerFragment digit $keyNumber clicked")
    }
}
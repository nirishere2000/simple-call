package com.nirotem.simplecall

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telecom.TelecomManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.navigation.NavigationView
import com.google.android.material.snackbar.Snackbar
import com.nirotem.simplecall.databinding.ActivityMainBinding
import com.nirotem.simplecall.managers.SoundPoolManager


class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding
    private val requestedCode = 100 // Define a request code
    private val REQUEST_ID = 1;
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var permissionsLauncher: ActivityResultLauncher<Array<String>>
    private lateinit var overlayPermissionLauncher: ActivityResultLauncher<Intent>
    private lateinit var roleManagerLauncher: ActivityResultLauncher<Intent>
    private val REQUEST_CODE_ROLE_DIALER = 1001
    private lateinit var roleRequestLauncher: ActivityResultLauncher<Intent>
    private val OVERLAY_PERMISSION_REQUEST_CODE = 1000

    @RequiresApi(Build.VERSION_CODES.Q)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        SoundPoolManager.initialize(this)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.appBarMain.toolbar)
        // Initialize the handler and start the ringtone
        Log.d("SimplyCall - MainActivity", "Main activity loading")

        // Load sound during app initialization

        loadUI()
        if (!Settings.canDrawOverlays(this)) {
            val intent =
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST_CODE)
        }


        /*        if (!Settings.canDrawOverlays(this)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST_CODE)
                }*/

        /*
                val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                intent.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                startActivity(intent)
        */

// Request to become the default dialer:
        //   val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
        val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
        val isDefaultDialer = telecomManager.defaultDialerPackage == packageName

        Log.d("SimplyCall - MainActivity", "isDefaultDialer = $isDefaultDialer")
        Log.d(
            "SimplyCall - MainActivity",
            "defaultDialerPackage = $telecomManager.defaultDialerPackage"
        )

        roleRequestLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    Log.d("DefaultDialer", "App successfully became the default dialer")
                } else {
                    Log.d("DefaultDialer", "User denied the role request")
                }
            }
        requestDefaultDialerRole()

        // Launcher for role manager
        Log.d("SimplyCall", "Requesting ROLE_DIALER with package: $packageName")
        /*        val intentChangeDefaultDialerTelcom = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                intentChangeDefaultDialerTelcom.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                startActivity(intentChangeDefaultDialerTelcom)*/
        //   requestRole()


        if (telecomManager.defaultDialerPackage != packageName) {
            mediaPlayer = MediaPlayer.create(this, R.raw.welcome_instructions)
            // Start playback
            mediaPlayer.start()

            // TODO: Pop up a help screen

/*            binding.appBarMain.contentMain.bottomNavView?.let {
                it.selectedItemId =     // If app is not the default dialer then explicitly
                    R.id.nav_transform  // set Help as the default Window to load - to help the user
            }*/
            val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).apply {
                putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            }
            startActivity(intent)
        } else {
            Log.d("SimplyCall", "App is already the default dialer")
        }
        requestContactPermissions()

        //    if (!isDefaultDialer) {
        /*            val telecomManager = getSystemService(TELECOM_SERVICE) as TelecomManager
                    val intentChangeDefaultDialerTelcom = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                    intentChangeDefaultDialerTelcom.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                    startActivity(intentChangeDefaultDialerTelcom)*/


        //   val intentChangeDefaultDialer = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
        //   intentChangeDefaultDialer.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
        //    startActivity(intentChangeDefaultDialer)
        //    Log.d("SimplyCall - MainActivity", "isDefaultDialer After = $telecomManager.defaultDialerPackage")
        //}

        //    requestRole()
        // initLaunchers()
        // requestAllPermissions()

        // Start the service:
        // val serviceIntent = Intent(this, CallService::class.java)

        // if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE)
        //   != PackageManager.PERMISSION_GRANTED) {
        // ActivityCompat.requestPermissions(activity,
        //   arrayOf(Manifest.permission.READ_PHONE_STATE), requestCode)
        //   } else {
        //     // אם יש כבר הרשאה, נרשם ישירות לרסיבר
        //   registerReceiver()
        // }

        /*        val defaultDialerIntent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                intent.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                startActivity(defaultDialerIntent)*/


        /*        if (!Settings.canDrawOverlays(this)) { // so we can draw over other UI when there is incoming call or active call
                    val drawPermissionsIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${this.packageName}"))
                    this.startActivity(drawPermissionsIntent)
                }*/

        // Check if the permission is granted
        /*    if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {

                // Request the permission if not granted
                ActivityCompat.requestPermissions(this,  // Use `this` here
                    arrayOf(Manifest.permission.READ_PHONE_STATE), requestedCode)
            } else {
                // If permission is already granted, register the receiver

                // Start the Foreground Service

                //startService(serviceIntent)
            }*/

        /*        val serviceIntent = Intent(
                    this,
                    ForegroundService::class.java
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    // For Android 8.0 (API 26) and above
                    ContextCompat.startForegroundService(this, serviceIntent)
                } else {
                    // For earlier Android versions
                    startService(serviceIntent)
                }*/

        //Toast.makeText(this, "Finished Loading", Toast.LENGTH_SHORT).show()
        Log.d("SimplyCall - MainActivity", "Main activity finished loading")

        // Check if we have permission
        // if (ContextCompat.checkSelfPermission(this, Manifest.permission.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
        // Request permission if not granted
        //   ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_PHONE_STATE), 1)
        //} else {
        //  Toast.makeText(this, "Permission granted!", Toast.LENGTH_SHORT).show()
        //}
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestedCode && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // אם ההרשאה אושרה, נרשם לרסיבר
            // registerReceiver()
            //val serviceIntent = Intent(this, CallService::class.java)
            //startService(serviceIntent)
        } else {
            // אם ההרשאה נדחתה, הצג הודעת שגיאה או התנהגויות חלופיות
            //Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
        }
    }


    // Your BroadcastReceiver to listen for phone state changes
    /*    private val callReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                Log.d("CallReceiver", "Phone state changed!")
                // Add your logic here, e.g., show a Toast for incoming call
                showToast(context, "Phone state changed!")
            }
        }*/

    /*    private fun registerReceiver() {
            val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
           registerReceiver(callReceiver, filter)
        }*/


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val result = super.onCreateOptionsMenu(menu)
        // Using findViewById because NavigationView exists in different layout files
        // between w600dp and w1240dp
        val navView: NavigationView? = findViewById(R.id.nav_view)
        if (navView == null) {
            // The navigation drawer already has the items including the items in the overflow menu
            // We only inflate the overflow menu if the navigation drawer isn't visible
            menuInflater.inflate(R.menu.overflow, menu)
        }
        return result
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_settings -> {
                val navController = findNavController(R.id.nav_host_fragment_content_main)
                navController.navigate(R.id.nav_settings)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    override fun onDestroy() {
        super.onDestroy()
        //unregisterReceiver(callReceiver)
        // Release the MediaPlayer to avoid memory leaks
        mediaPlayer.release()
    }

    /*    private fun requestAllPermissions() {
            permissionsLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
                permissions.entries.forEach { entry ->
                    val permission = entry.key
                    val isGranted = entry.value
                    if (isGranted) {
                        Log.d("SimplyCall - MainActivity", "$permission granted")
                    } else {
                        Log.d("SimplyCall - MainActivity", "$permission denied")
                    }
                }
            }

            requestPermissions()
        }*/

    /* private fun requestPermissions() {
         val permissions = arrayOf(
             Manifest.permission.CAMERA,
             Manifest.permission.READ_CONTACTS,
             Manifest.permission.ACCESS_FINE_LOCATION
         )

         val permissionsToRequest = permissions.filter {
             ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
         }.toTypedArray()

         if (permissionsToRequest.isNotEmpty()) {
             permissionsLauncher.launch(permissionsToRequest)
         } else {
             Log.d("SimplyCall - MainActivity", "All permissions granted")
         }
     }*/

    @RequiresApi(Build.VERSION_CODES.Q)
    fun requestRole() {
        /*        val roleManager = getSystemService(ROLE_SERVICE) as RoleManager
                val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
                startActivityForResult(intent, REQUEST_ID)*/
        val roleManager = getSystemService(ROLE_SERVICE) as RoleManager
        if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) &&
            !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)
        ) {
            val roleRequestIntent = roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
            startActivityForResult(roleRequestIntent, REQUEST_CODE_ROLE_DIALER)
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun requestDefaultDialerRole() {
        val roleManager = getSystemService(ROLE_SERVICE) as RoleManager
        if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) &&
            !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)
        ) {
            val roleRequestIntent = roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
            roleRequestLauncher.launch(roleRequestIntent)
        }
    }

    /*    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
            super.onActivityResult(requestCode, resultCode, data)
            if (requestCode == REQUEST_ID) {
                if (resultCode == RESULT_OK) {
                    // Your app is now the default dialer app
                } else {
                    // Your app is not the default dialer app
                }
            }
        }*/

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun initLaunchers() {
        // Permission launcher for runtime permissions
        permissionsLauncher =
            registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
                if (permissions[Manifest.permission.READ_PHONE_STATE] == true) {
                    checkOverlayPermission()
                } else {
                    Toast.makeText(this, "Phone state permission denied", Toast.LENGTH_SHORT).show()
                    // Handle rejection here if needed
                }
            }

        // Launcher for overlay permission
        overlayPermissionLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
                if (Settings.canDrawOverlays(this)) {
                    checkDefaultDialerRole()
                } else {
                    Toast.makeText(this, "Overlay permission denied", Toast.LENGTH_SHORT).show()
                    // Handle rejection here if needed
                }
            }

        // Launcher for role manager
        roleManagerLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
                val roleManager = getSystemService(ROLE_SERVICE) as RoleManager
                if (roleManager.isRoleHeld(RoleManager.ROLE_DIALER)) {
                    loadUI()
                } else {
                    Toast.makeText(this, "Default dialer role denied", Toast.LENGTH_SHORT).show()
                    // Handle rejection here if needed
                }
            }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun checkReadPhoneStatePermission() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_PHONE_STATE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Request the permission
            permissionsLauncher.launch(arrayOf(Manifest.permission.READ_PHONE_STATE))
        } else {
            // Permission already granted, move to the next step
            checkOverlayPermission()
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun checkOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            // Request overlay permission
            val intent =
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            overlayPermissionLauncher.launch(intent)
        } else {
            // Permission already granted, move to the next step
            checkDefaultDialerRole()
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun checkDefaultDialerRole() {
        val roleManager = getSystemService(ROLE_SERVICE) as RoleManager
        if (!roleManager.isRoleHeld(RoleManager.ROLE_DIALER)) {
            // Request default dialer role
            val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
            roleManagerLauncher.launch(intent)
        } else {
            // Role already granted, proceed to load UI
            // loadUI()
        }
    }

    private fun requestContactPermissions() {
        val permissions = arrayOf(
            android.Manifest.permission.READ_CONTACTS,
            android.Manifest.permission.READ_CALL_LOG
        )

        if (permissions.any {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }) {
            ActivityCompat.requestPermissions(this, permissions, 1)
        }
    }

    private fun loadUI() {
        // Load your UI after all permissions and roles are granted
        binding.appBarMain.fab?.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null)
                .setAnchorView(R.id.fab).show()
        }

        val navHostFragment =
            (supportFragmentManager.findFragmentById(R.id.nav_host_fragment_content_main) as NavHostFragment?)!!
        val navController = navHostFragment.navController

        binding.navView?.let {
            appBarConfiguration = AppBarConfiguration(
                setOf(
                    R.id.nav_dialer, R.id.nav_contacts, R.id.nav_recent_calls, R.id.nav_settings
                ),
                binding.drawerLayout
            )
            setupActionBarWithNavController(navController, appBarConfiguration)
            it.setupWithNavController(navController)
        }

        binding.appBarMain.contentMain.bottomNavView?.let {
            appBarConfiguration = AppBarConfiguration(
                setOf(
                    R.id.nav_recent_calls, R.id.nav_contacts, R.id.nav_dialer
                )
            )
            setupActionBarWithNavController(navController, appBarConfiguration)
            it.setupWithNavController(navController)
        }

        binding.appBarMain.contentMain.bottomNavView?.let {
            it.selectedItemId =
                R.id.nav_recent_calls  // This explicitly sets the first item as the default
        }
    }
}